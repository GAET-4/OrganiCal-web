/*
  # Initial Schema for OrganiCal

  1. New Tables
    - `profiles`
      - `id` (uuid, primary key) - matches auth.users.id
      - `full_name` (text)
      - `avatar_url` (text)
      - `phone` (text)
      - `birthday` (date)
      - `updated_at` (timestamp)
    
    - `groups`
      - `id` (uuid, primary key)
      - `name` (text)
      - `owner_id` (uuid) - references profiles.id
      - `created_at` (timestamp)
    
    - `birthdays`
      - `id` (uuid, primary key)
      - `first_name` (text)
      - `last_name` (text)
      - `birth_date` (date)
      - `group_id` (uuid) - references groups.id
      - `created_by` (uuid) - references profiles.id
      - `created_at` (timestamp)
      - `has_year` (boolean)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create profiles table
CREATE TABLE profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  full_name text,
  avatar_url text,
  phone text,
  birthday date,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read their own profile"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Create groups table
CREATE TABLE groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  owner_id uuid REFERENCES profiles(id) NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE groups ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read their own groups"
  ON groups
  FOR SELECT
  TO authenticated
  USING (owner_id = auth.uid());

CREATE POLICY "Users can insert their own groups"
  ON groups
  FOR INSERT
  TO authenticated
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY "Users can update their own groups"
  ON groups
  FOR UPDATE
  TO authenticated
  USING (owner_id = auth.uid());

CREATE POLICY "Users can delete their own groups"
  ON groups
  FOR DELETE
  TO authenticated
  USING (owner_id = auth.uid());

-- Create birthdays table
CREATE TABLE birthdays (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  first_name text NOT NULL,
  last_name text,
  birth_date date NOT NULL,
  group_id uuid REFERENCES groups(id),
  created_by uuid REFERENCES profiles(id) NOT NULL,
  created_at timestamptz DEFAULT now(),
  has_year boolean DEFAULT true
);

ALTER TABLE birthdays ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read their own birthdays"
  ON birthdays
  FOR SELECT
  TO authenticated
  USING (created_by = auth.uid());

CREATE POLICY "Users can insert their own birthdays"
  ON birthdays
  FOR INSERT
  TO authenticated
  WITH CHECK (created_by = auth.uid());

CREATE POLICY "Users can update their own birthdays"
  ON birthdays
  FOR UPDATE
  TO authenticated
  USING (created_by = auth.uid());

CREATE POLICY "Users can delete their own birthdays"
  ON birthdays
  FOR DELETE
  TO authenticated
  USING (created_by = auth.uid());

-- Create indexes for better performance
CREATE INDEX birthdays_birth_date_idx ON birthdays(birth_date);
CREATE INDEX birthdays_group_id_idx ON birthdays(group_id);
CREATE INDEX groups_owner_id_idx ON groups(owner_id);