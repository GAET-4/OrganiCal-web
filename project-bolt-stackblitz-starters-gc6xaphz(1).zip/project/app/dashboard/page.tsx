import { format, isBefore } from 'date-fns';
import { fr } from 'date-fns/locale';
import BirthdayCard from '../components/BirthdayCard';

// Simulated data for now
const birthdays = [
  { id: 1, firstName: 'Marie', lastName: 'Dupont', birthDate: '1990-03-15', group: 'Famille' },
  { id: 2, firstName: 'Jean', lastName: 'Martin', birthDate: '1985-04-20', group: 'Amis' },
  { id: 3, firstName: 'Sophie', lastName: 'Bernard', birthDate: '1995-05-10', group: 'Travail' },
  { id: 4, firstName: 'Titouan', lastName: 'DEVERMEILLE', birthDate: '1997-04-17', group: 'Amis' },
  { id: 5, firstName: 'Paul', lastName: 'ARNAUD', birthDate: '1997-05-08', group: 'Amis' },
  { id: 6, firstName: 'Léa', lastName: 'CATTEAU', birthDate: '1998-05-11', group: 'Amis' },
  { id: 7, firstName: 'Bénédicte', lastName: 'FERREIRA', birthDate: '1997-03-27' },
];

function getNextBirthdays(birthdays: any[], limit = 5) {
  const today = new Date();
  const currentYear = today.getFullYear();

  return birthdays
    .map(birthday => {
      const birthDate = new Date(birthday.birthDate);
      const nextBirthday = new Date(currentYear, birthDate.getMonth(), birthDate.getDate());
      
      if (isBefore(nextBirthday, today)) {
        nextBirthday.setFullYear(currentYear + 1);
      }

      return { ...birthday, nextBirthday };
    })
    .sort((a, b) => a.nextBirthday.getTime() - b.nextBirthday.getTime())
    .slice(0, limit);
}

export default function Dashboard() {
  const nextBirthdays = getNextBirthdays(birthdays);

  return (
    <main className="max-w-7xl mx-auto p-4">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">
        Bienvenue sur OrganiCal !
      </h1>
      
      <section className="mb-8">
        <h2 className="text-xl font-semibold text-gray-800 mb-4">
          Prochains anniversaires
        </h2>
        
        {nextBirthdays.length > 0 ? (
          <div className="space-y-3">
            {nextBirthdays.map(birthday => (
              <BirthdayCard
                key={birthday.id}
                firstName={birthday.firstName}
                lastName={birthday.lastName}
                birthDate={birthday.birthDate}
                group={birthday.group}
              />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-[40px] shadow p-8 text-center">
            <p className="text-gray-500">Aucun anniversaire à venir</p>
            <button className="mt-4 btn-primary">
              Ajouter un anniversaire
            </button>
          </div>
        )}
      </section>
    </main>
  );
}