'use client';

import Link from 'next/link';
import { Home, List, Users, User, Plus } from 'lucide-react';
import { usePathname } from 'next/navigation';

export default function Navbar() {
  const pathname = usePathname();

  const getNewButton = () => {
    if (pathname === '/birthdays') {
      return (
        <Link 
          href="/birthdays/new" 
          className="btn-primary flex items-center space-x-2"
        >
          <Plus size={20} />
          <span>Nouvel anniversaire</span>
        </Link>
      );
    }
    if (pathname === '/groups') {
      return (
        <Link 
          href="/groups/new" 
          className="btn-primary flex items-center space-x-2"
        >
          <Plus size={20} />
          <span>Nouveau groupe</span>
        </Link>
      );
    }
    return null;
  };

  return (
    <div className="sticky top-8 mx-8 z-50">
      <nav className="bg-white shadow-lg rounded-[40px] px-8 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-8">
            <Link href="/dashboard" className="flex flex-col items-center text-gray-600 hover:text-indigo-600">
              <Home size={24} />
              <span className="text-xs mt-1">Accueil</span>
            </Link>
            <Link href="/birthdays" className="flex flex-col items-center text-gray-600 hover:text-indigo-600">
              <List size={24} />
              <span className="text-xs mt-1">Anniversaires</span>
            </Link>
            <Link href="/groups" className="flex flex-col items-center text-gray-600 hover:text-indigo-600">
              <Users size={24} />
              <span className="text-xs mt-1">Groupes</span>
            </Link>
          </div>
          
          <div className="flex items-center space-x-4">
            {getNewButton()}
            <Link href="/profile" className="flex items-center space-x-3 text-gray-600 hover:text-indigo-600">
              <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
                <User size={20} />
              </div>
              <span className="hidden md:inline">John Doe</span>
            </Link>
          </div>
        </div>
      </nav>
    </div>
  );
}