'use client';

import { User } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import Link from 'next/link';

type BirthdayCardProps = {
  id?: number;
  firstName: string;
  lastName: string;
  birthDate: string;
  group?: string;
  avatarUrl?: string;
};

export default function BirthdayCard({ id, firstName, lastName, birthDate, group, avatarUrl }: BirthdayCardProps) {
  const birthYear = new Date(birthDate).getFullYear();
  const nextBirthday = new Date(birthDate);
  const today = new Date();
  
  // Set next birthday to this year
  nextBirthday.setFullYear(today.getFullYear());
  
  // If the birthday has already passed this year, set it to next year
  if (nextBirthday < today) {
    nextBirthday.setFullYear(today.getFullYear() + 1);
  }

  const content = (
    <div className="bg-white rounded-[40px] shadow py-4 px-6 flex items-center justify-between hover:shadow-md transition-shadow my-1">
      <div className="flex items-center space-x-4">
        <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
          {avatarUrl ? (
            <img src={avatarUrl} alt={`${firstName} ${lastName}`} className="w-full h-full object-cover" />
          ) : (
            <User size={24} className="text-gray-500" />
          )}
        </div>
        <div>
          <h3 className="font-medium text-gray-900">
            {firstName} {lastName}
          </h3>
          {birthYear && (
            <p className="text-sm text-gray-500">
              Né(e) en {birthYear}
            </p>
          )}
        </div>
      </div>
      <div className="text-right">
        <p className="font-medium text-[#178cd0]">
          {format(nextBirthday, 'EEEE d MMMM', { locale: fr })}
        </p>
        {group && (
          <span className="inline-block mt-2 px-3 py-1 bg-gray-100 text-gray-600 text-sm rounded-[40px]">
            {group}
          </span>
        )}
      </div>
    </div>
  );

  if (id) {
    return (
      <Link href={`/birthdays/edit/${id}`}>
        {content}
      </Link>
    );
  }

  return content;
}