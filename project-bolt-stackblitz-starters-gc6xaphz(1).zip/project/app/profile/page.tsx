'use client';

import { useState } from 'react';
import { User, Mail, Phone, Lock, LogOut, Trash2, Edit } from 'lucide-react';
import { useRouter } from 'next/navigation';

// Simulated user data for now
const user = {
  firstName: 'John',
  lastName: 'Doe',
  email: 'john.doe@example.com',
  phone: '+33 6 12 34 56 78',
  avatarUrl: null,
};

export default function Profile() {
  const router = useRouter();
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleLogout = () => {
    // Ici on déconnectera l'utilisateur via Supabase
    router.push('/auth/signin');
  };

  const handleDeleteAccount = () => {
    // Ici on supprimera le compte via Supabase
    router.push('/auth/signin');
  };

  return (
    <main className="max-w-3xl mx-auto p-4">
      <div className="bg-white rounded-[40px] shadow-lg p-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Mon profil</h1>

        <div className="space-y-8">
          {/* Photo de profil */}
          <div className="flex flex-col items-center space-y-4">
            <div className="w-32 h-32 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
              {avatarPreview || user.avatarUrl ? (
                <img 
                  src={avatarPreview || user.avatarUrl!} 
                  alt="Photo de profil" 
                  className="w-full h-full object-cover" 
                />
              ) : (
                <User size={48} className="text-gray-500" />
              )}
            </div>
            <label className="btn-secondary cursor-pointer">
              <input type="file" className="hidden" accept="image/*" onChange={handleImageChange} />
              Changer la photo
            </label>
          </div>

          {/* Informations */}
          <div className="space-y-6">
            <div className="flex items-center space-x-4 text-gray-600">
              <User size={24} />
              <div>
                <p className="font-medium">Nom complet</p>
                <p>{user.firstName} {user.lastName}</p>
              </div>
            </div>

            <div className="flex items-center space-x-4 text-gray-600">
              <Mail size={24} />
              <div>
                <p className="font-medium">Adresse e-mail</p>
                <p>{user.email}</p>
              </div>
            </div>

            <div className="flex items-center space-x-4 text-gray-600">
              <Phone size={24} />
              <div>
                <p className="font-medium">Numéro de téléphone</p>
                <p>{user.phone || 'Non renseigné'}</p>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="space-y-4">
            <button 
              onClick={() => router.push('/profile/edit')}
              className="btn-primary w-full flex items-center justify-center space-x-2"
            >
              <Edit size={20} />
              <span>Modifier mon profil</span>
            </button>

            <button 
              onClick={() => router.push('/profile/password')}
              className="btn-secondary w-full flex items-center justify-center space-x-2"
            >
              <Lock size={20} />
              <span>Modifier mon mot de passe</span>
            </button>

            <button 
              onClick={handleLogout}
              className="btn-secondary w-full flex items-center justify-center space-x-2"
            >
              <LogOut size={20} />
              <span>Se déconnecter</span>
            </button>

            <button 
              onClick={() => setShowDeleteModal(true)}
              className="btn-secondary w-full flex items-center justify-center space-x-2 text-red-600 hover:bg-red-50"
            >
              <Trash2 size={20} />
              <span>Supprimer mon compte</span>
            </button>
          </div>
        </div>
      </div>

      {/* Modal de confirmation de suppression */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-[40px] p-8 max-w-md w-full">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Supprimer mon compte
            </h2>
            <p className="text-gray-600 mb-8">
              Êtes-vous sûr de vouloir supprimer votre compte ? Cette action est irréversible et supprimera toutes vos données.
            </p>
            <div className="flex space-x-4">
              <button
                onClick={() => setShowDeleteModal(false)}
                className="btn-secondary flex-1"
              >
                Annuler
              </button>
              <button
                onClick={handleDeleteAccount}
                className="btn-primary flex-1 bg-red-600 hover:bg-red-700"
              >
                Supprimer
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}