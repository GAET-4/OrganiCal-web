'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { User, ArrowLeft } from 'lucide-react';
import Link from 'next/link';

// Simulated user data for now
const user = {
  firstName: 'John',
  lastName: 'Doe',
  email: 'john.doe@example.com',
  phone: '+33 6 12 34 56 78',
  avatarUrl: null,
};

export default function EditProfile() {
  const router = useRouter();
  const [firstName, setFirstName] = useState(user.firstName);
  const [lastName, setLastName] = useState(user.lastName);
  const [email, setEmail] = useState(user.email);
  const [phone, setPhone] = useState(user.phone || '');
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Ici on mettra à jour le profil via Supabase
    router.push('/profile');
  };

  return (
    <main className="max-w-3xl mx-auto p-4">
      <Link href="/profile" className="inline-flex items-center text-gray-600 hover:text-[#178cd0] mb-6">
        <ArrowLeft size={20} className="mr-2" />
        Retour au profil
      </Link>

      <form onSubmit={handleSubmit} className="bg-white rounded-[40px] shadow-lg p-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">
          Modifier mon profil
        </h1>

        <div className="space-y-8">
          {/* Photo de profil */}
          <div className="flex flex-col items-center space-y-4">
            <div className="w-32 h-32 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
              {avatarPreview || user.avatarUrl ? (
                <img 
                  src={avatarPreview || user.avatarUrl!} 
                  alt="Photo de profil" 
                  className="w-full h-full object-cover" 
                />
              ) : (
                <User size={48} className="text-gray-500" />
              )}
            </div>
            <label className="btn-secondary cursor-pointer">
              <input type="file" className="hidden" accept="image/*" onChange={handleImageChange} />
              Changer la photo
            </label>
          </div>

          {/* Champs */}
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">
                  Prénom
                </label>
                <input
                  type="text"
                  id="firstName"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  className="input"
                  required
                />
              </div>
              <div>
                <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1">
                  Nom
                </label>
                <input
                  type="text"
                  id="lastName"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  className="input"
                  required
                />
              </div>
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Adresse e-mail
              </label>
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="input"
                required
              />
            </div>

            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                Numéro de téléphone
              </label>
              <input
                type="tel"
                id="phone"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="input"
                placeholder="+33 6 12 34 56 78"
              />
            </div>
          </div>

          {/* Boutons */}
          <div className="flex space-x-4">
            <button
              type="button"
              onClick={() => router.back()}
              className="btn-secondary flex-1"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="btn-primary flex-1"
            >
              Enregistrer
            </button>
          </div>
        </div>
      </form>
    </main>
  );
}