import Link from 'next/link';

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900">OrganiCal</h1>
          <p className="mt-2 text-gray-600">
            Gérez les anniversaires de vos proches en toute simplicité
          </p>
        </div>
        
        <div className="space-y-4">
          <Link 
            href="/dashboard"
            className="w-full flex items-center justify-center px-4 py-3 border border-transparent text-base font-medium rounded-[40px] text-white bg-indigo-600 hover:bg-indigo-700"
          >
            Accéder à l'application
          </Link>
        </div>
      </div>
    </main>
  );
}