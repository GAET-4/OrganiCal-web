import './globals.css';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import Navbar from './components/Navbar';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'OrganiCal - Gestionnaire d\'anniversaires',
  description: 'Une application intuitive pour se souvenir des anniversaires de ses proches',
  icons: {
    icon: '/vercel.svg', // Using an existing SVG as favicon temporarily
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr">
      <body className={`${inter.className} bg-gray-50`}>
        <Navbar />
        <div className="p-8">
          {children}
        </div>
      </body>
    </html>
  );
}