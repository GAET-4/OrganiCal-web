import Link from 'next/link';
import { Plus } from 'lucide-react';

// Simulated data for now
const groups = [
  { id: 1, name: 'Famille', count: 5 },
  { id: 2, name: 'Amis', count: 3 },
  { id: 3, name: 'Travail', count: 2 },
];

export default function Groups() {
  return (
    <main className="max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-gray-900">
          Groupes
        </h1>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {groups.map(group => (
          <Link 
            key={group.id} 
            href={`/groups/${group.id}`}
            className="bg-white rounded-[40px] shadow p-6 hover:shadow-md transition-shadow"
          >
            <h3 className="font-medium text-gray-900 text-lg mb-2">
              {group.name}
            </h3>
            <p className="text-sm text-gray-500">
              {group.count} {group.count > 1 ? 'anniversaires' : 'anniversaire'}
            </p>
          </Link>
        ))}
      </div>
    </main>
  );
}