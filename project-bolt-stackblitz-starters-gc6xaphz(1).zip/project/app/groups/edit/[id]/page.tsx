'use client';

import { useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { Users } from 'lucide-react';

// Simulated data for now
const groups = [
  { id: 1, name: 'Famille', count: 5 },
  { id: 2, name: 'Amis', count: 3 },
  { id: 3, name: 'Travail', count: 2 },
];

export default function EditGroup() {
  const router = useRouter();
  const params = useParams();
  const group = groups.find(g => g.id === Number(params.id));
  const [groupName, setGroupName] = useState(group?.name || '');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Ici on mettra à jour le groupe dans Supabase
    router.back();
  };

  if (!group) {
    router.back();
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-[40px] p-8 max-w-md w-full">
        <div className="flex items-center space-x-4 mb-6">
          <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center">
            <Users size={24} className="text-gray-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900">
            Modifier le groupe
          </h1>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="mb-6">
            <label htmlFor="groupName" className="block text-sm font-medium text-gray-700 mb-2">
              Nom du groupe
            </label>
            <input
              type="text"
              id="groupName"
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
              className="input"
              placeholder="Ex: Famille, Amis, Travail..."
              autoFocus
            />
          </div>

          <div className="flex space-x-4">
            <button
              type="button"
              onClick={() => router.back()}
              className="btn-secondary flex-1"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="btn-primary flex-1"
              disabled={!groupName.trim()}
            >
              Enregistrer
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}