'use client';

import { format, parse } from 'date-fns';
import { fr } from 'date-fns/locale';
import { ChevronDown, ChevronRight } from 'lucide-react';
import { useState } from 'react';
import BirthdayCard from '../components/BirthdayCard';

// Simulated data for now
const birthdays = [
  { id: 1, firstName: 'Marie', lastName: 'Dupont', birthDate: '1990-03-15', group: 'Famille' },
  { id: 2, firstName: 'Jean', lastName: 'Martin', birthDate: '1985-04-20', group: 'Amis' },
  { id: 3, firstName: 'Sophie', lastName: 'Bernard', birthDate: '1995-05-10', group: 'Travail' },
  { id: 4, firstName: 'Titouan', lastName: 'DEVERMEILLE', birthDate: '1997-04-17', group: 'Amis' },
  { id: 5, firstName: 'Paul', lastName: 'ARNAUD', birthDate: '1997-05-08', group: 'Amis' },
  { id: 6, firstName: 'Léa', lastName: 'CATTEAU', birthDate: '1998-05-11', group: 'Amis' },
  { id: 7, firstName: 'Bénédicte', lastName: 'FERREIRA', birthDate: '1997-03-27' },
];

// Fonction pour grouper les anniversaires par mois
function groupBirthdaysByMonth(birthdays: any[]) {
  const grouped = birthdays.reduce((acc, birthday) => {
    const date = parse(birthday.birthDate, 'yyyy-MM-dd', new Date());
    const month = date.getMonth();
    
    if (!acc[month]) {
      acc[month] = [];
    }
    
    acc[month].push(birthday);
    return acc;
  }, {});

  // Trier les anniversaires de chaque mois par jour
  Object.keys(grouped).forEach(month => {
    grouped[month].sort((a: any, b: any) => {
      const dateA = parse(a.birthDate, 'yyyy-MM-dd', new Date());
      const dateB = parse(b.birthDate, 'yyyy-MM-dd', new Date());
      return dateA.getDate() - dateB.getDate();
    });
  });

  return grouped;
}

export default function Birthdays() {
  const groupedBirthdays = groupBirthdaysByMonth(birthdays);
  const months = Object.keys(groupedBirthdays).sort((a, b) => Number(a) - Number(b));
  const [collapsedMonths, setCollapsedMonths] = useState<Record<string, boolean>>({});

  const toggleMonth = (month: string) => {
    setCollapsedMonths(prev => ({
      ...prev,
      [month]: !prev[month]
    }));
  };

  return (
    <main className="max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-gray-900">
          Anniversaires
        </h1>
      </div>
      
      <div className="space-y-6">
        {months.map(month => {
          const monthDate = new Date(2024, Number(month), 1);
          const isCollapsed = collapsedMonths[month];
          return (
            <div key={month}>
              <button 
                onClick={() => toggleMonth(month)}
                className="w-full flex items-center space-x-4 mb-3 group"
              >
                {isCollapsed ? (
                  <ChevronRight size={20} className="text-gray-400 group-hover:text-gray-600" />
                ) : (
                  <ChevronDown size={20} className="text-gray-400 group-hover:text-gray-600" />
                )}
                <h2 className="text-lg font-semibold text-gray-700 group-hover:text-gray-900">
                  {format(monthDate, 'MMMM', { locale: fr })}
                </h2>
                <div className="flex-1 h-px bg-gray-200"></div>
              </button>
              {!isCollapsed && (
                <div className="space-y-3">
                  {groupedBirthdays[month].map((birthday: any) => (
                    <BirthdayCard
                      key={birthday.id}
                      id={birthday.id}
                      firstName={birthday.firstName}
                      lastName={birthday.lastName}
                      birthDate={birthday.birthDate}
                      group={birthday.group}
                    />
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </main>
  );
}