'use client';

import { useParams } from 'next/navigation';
import { User, Calendar, Users, Cake, ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

// Simulated data for now
const birthdays = [
  { id: 1, firstName: 'Marie', lastName: 'Dupont', birthDate: '1990-03-15', group: 'Famille' },
  { id: 2, firstName: 'Jean', lastName: 'Martin', birthDate: '1985-04-20', group: 'Amis' },
  { id: 3, firstName: 'Sophie', lastName: 'Bernard', birthDate: '1995-05-10', group: 'Travail' },
];

export default function BirthdayDetails() {
  const params = useParams();
  const birthday = birthdays.find(b => b.id === Number(params.id));

  if (!birthday) {
    return (
      <div className="max-w-3xl mx-auto p-4">
        <p className="text-center text-gray-600">Anniversaire non trouvé</p>
      </div>
    );
  }

  const birthDate = new Date(birthday.birthDate);
  const age = new Date().getFullYear() - birthDate.getFullYear();

  return (
    <main className="max-w-3xl mx-auto p-4">
      <Link href="/birthdays" className="inline-flex items-center text-gray-600 hover:text-indigo-600 mb-6">
        <ArrowLeft size={20} className="mr-2" />
        Retour aux anniversaires
      </Link>

      <div className="bg-white rounded-[40px] shadow-lg p-8">
        <div className="flex items-center space-x-6 mb-8">
          <div className="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center">
            <User size={40} className="text-gray-500" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              {birthday.firstName} {birthday.lastName}
            </h1>
            <p className="text-lg text-gray-600">
              {age} ans
            </p>
          </div>
        </div>

        <div className="space-y-6">
          <div className="flex items-center space-x-4 text-gray-600">
            <Calendar size={24} />
            <div>
              <p className="font-medium">Date de naissance</p>
              <p>{format(birthDate, 'dd MMMM yyyy', { locale: fr })}</p>
            </div>
          </div>

          <div className="flex items-center space-x-4 text-gray-600">
            <Cake size={24} />
            <div>
              <p className="font-medium">Prochain anniversaire</p>
              <p>{format(birthDate, 'EEEE dd MMMM', { locale: fr })}</p>
            </div>
          </div>

          <div className="flex items-center space-x-4 text-gray-600">
            <Users size={24} />
            <div>
              <p className="font-medium">Groupe</p>
              <p>{birthday.group}</p>
            </div>
          </div>
        </div>

        <div className="mt-8 flex space-x-4">
          <button className="btn-primary flex-1">
            Modifier
          </button>
          <button className="btn-secondary flex-1 text-red-600 hover:bg-red-50">
            Supprimer
          </button>
        </div>
      </div>
    </main>
  );
}