'use client';

import { useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { User, ArrowLeft, Trash2 } from 'lucide-react';
import Link from 'next/link';
import { format } from 'date-fns';

// Simulated data for now
const birthdays = [
  { id: 1, firstName: 'Marie', lastName: 'Dupont', birthDate: '1990-03-15', group: 'Famille' },
  { id: 2, firstName: 'Jean', lastName: 'Martin', birthDate: '1985-04-20', group: 'Amis' },
  { id: 3, firstName: 'Sophie', lastName: 'Bernard', birthDate: '1995-05-10', group: 'Travail' },
];

const groups = [
  { id: 1, name: 'Famille' },
  { id: 2, name: 'Amis' },
  { id: 3, name: 'Travail' },
];

export default function EditBirthday() {
  const params = useParams();
  const router = useRouter();
  const birthday = birthdays.find(b => b.id === Number(params.id));
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);

  if (!birthday) {
    return (
      <div className="max-w-3xl mx-auto p-4">
        <p className="text-center text-gray-600">Anniversaire non trouvé</p>
      </div>
    );
  }

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDelete = () => {
    // Ici on supprimera l'anniversaire
    router.push('/birthdays');
  };

  return (
    <main className="max-w-3xl mx-auto p-4">
      <Link href="/birthdays" className="inline-flex items-center text-gray-600 hover:text-indigo-600 mb-6">
        <ArrowLeft size={20} className="mr-2" />
        Retour aux anniversaires
      </Link>

      <form className="bg-white rounded-[40px] shadow-lg p-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">
          Modifier l'anniversaire
        </h1>

        <div className="space-y-6">
          {/* Photo */}
          <div className="flex flex-col items-center space-y-4">
            <div className="w-32 h-32 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
              {avatarPreview ? (
                <img src={avatarPreview} alt="Preview" className="w-full h-full object-cover" />
              ) : (
                <User size={48} className="text-gray-500" />
              )}
            </div>
            <label className="btn-secondary cursor-pointer">
              <input type="file" className="hidden" accept="image/*" onChange={handleImageChange} />
              Changer la photo
            </label>
          </div>

          {/* Nom et prénom */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">
                Prénom
              </label>
              <input
                type="text"
                id="firstName"
                defaultValue={birthday.firstName}
                className="input"
              />
            </div>
            <div>
              <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1">
                Nom
              </label>
              <input
                type="text"
                id="lastName"
                defaultValue={birthday.lastName}
                className="input"
              />
            </div>
          </div>

          {/* Date de naissance */}
          <div>
            <label htmlFor="birthDate" className="block text-sm font-medium text-gray-700 mb-1">
              Date de naissance
            </label>
            <input
              type="date"
              id="birthDate"
              defaultValue={birthday.birthDate}
              className="input"
            />
          </div>

          {/* Groupe */}
          <div>
            <label htmlFor="group" className="block text-sm font-medium text-gray-700 mb-1">
              Groupe
            </label>
            <select id="group" defaultValue={birthday.group} className="input">
              <option value="">Aucun groupe</option>
              {groups.map(group => (
                <option key={group.id} value={group.name}>
                  {group.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="mt-8 flex space-x-4">
          <button type="submit" className="btn-primary flex-1">
            Enregistrer
          </button>
          <button 
            type="button" 
            onClick={() => setShowDeleteModal(true)}
            className="btn-secondary flex-1 text-red-600 hover:bg-red-50"
          >
            Supprimer
          </button>
        </div>
      </form>

      {/* Modal de confirmation de suppression */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-[40px] p-8 max-w-md w-full">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Confirmer la suppression
            </h2>
            <p className="text-gray-600 mb-8">
              Êtes-vous sûr de vouloir supprimer cet anniversaire ? Cette action est irréversible.
            </p>
            <div className="flex space-x-4">
              <button
                onClick={() => setShowDeleteModal(false)}
                className="btn-secondary flex-1"
              >
                Annuler
              </button>
              <button
                onClick={handleDelete}
                className="btn-primary flex-1 bg-red-600 hover:bg-red-700"
              >
                Supprimer
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}