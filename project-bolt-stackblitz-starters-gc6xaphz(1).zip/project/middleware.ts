import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

// Bypass authentication for development
export function middleware(request: NextRequest) {
  // Simulate authenticated user
  const response = NextResponse.next();
  response.cookies.set('bypass-auth', 'true');
  return response;
}

// Add paths that would normally require authentication
export const config = {
  matcher: [
    '/dashboard/:path*',
    '/profile/:path*',
  ],
};